﻿const Discord = require('discord.js'); 
const bot = new Discord.Client();
let token = "NTMwMzcxODA0NDY0ODA3OTM4.XqcKZA.Pf_QFTmgg6f_OsueUvIldUOk9-M"
var bank = 0;
var inv = "";
var otm = 0;
var sms = 0;
var pere = 0;
var stat1 = "Serving servers from 2019!";
var stat2 = 'Type "b!debug (author)" for author!';
var stat3 = "Humans are cool!";
var stat4 = "YAHOO!";
var statosu = "osu!";
var statminecraft = "Minecraft";
var statdota = "Dota 2";
var statWoT = "Word of Tanks";
var ludi = "";
let fs = require('fs');
let list = ["-МакКомбо-", "-МакКоин-", "-ЛолиПоп-", "-Класическая_лоли-","-Мёд Таёжный Чёрный (Ульеград)-","-Сыр плавленный (Белура)-","-Винегрет-","-Сушки с маком (Прекрасный край)-"]
bot.on('ready', () => { 
    console.log("Bot " + bot.user.username + " started.");
    bot.user.verified = true;
    bot.user.setUsername('Butterscotch ✓')
    bot.user.setActivity("Serving servers from 2019!");
    bot.generateInvite(["ADMINISTRATOR"]).then(link => { 
        console.log("Invite link: " + link);
    });
});
bot.on('message', msg => {
        if(msg.content === "b!shop"){
            let p = 0;
            msg.channel.send("Вот мои товары:" + "\n" + list.toString());
            bot.on('message', item =>{
                if(p === 0){
                    if(list.includes(item.content)){
                        let user = item.author.username;
                        fs.readFile('./log.log', function(){
                            let app = user + ":" + item.toString() + "\n";
                            fs.appendFile('./log.log', app, function(err){
                                if (err) throw err;
                                console.log("Пользователь " + user + " купил " + item.toString());
                                msg.channel.send("Спасибо за покупку!");
                            });
                        });
                        p = 0.5;
                    }
                }
            });
        }
        if(msg.content === "b!shop inv"){
            var str = new Array;
            fs.readFile('./log.log', function(err, data){
                str = data.toString().split("\n");
                var user = msg.author.username;
                var soo = new String;
                for(i=0; i<str.length; i++){
                    var s = str[i];
                    var user1 = (s.split(":")[0]);
                    if(user1 === user){
                        soo += (s.split(":")[1]);
                    }
                    else{}
        
                }
                msg.channel.send("Ваш инвентарь: " + soo);
        
            });
        
        
        }

    if(msg.content === "b!balance"){
        msg.channel.send("Наш общий баланс: " + bank + " руб.");
    }
    if(msg.content === "b!add(100)"){
        msg.channel.send("Добавлено 100 рублей.");
        bank += 100;
    }
    if(msg.content === "b!remove(100)"){
        msg.channel.send("Снято 100 рублей.");
        bank -= 100;
    }
    if(msg.content === "b!debug (set-stat-stat1)"){
        bot.user.setActivity(stat1);
    }
    if(msg.content === "b!debug (set-stat-stat2)"){
        bot.user.setActivity(stat2);
    }
    if(msg.content === "b!debug (set-stat-stat3)"){
        bot.user.setActivity(stat3);
    }
    if(msg.content === "b!debug (set-stat-stat4)"){
        bot.user.setActivity(stat4);
    }
	if(msg.content === "b!debug (set-stat-stat5)"){
        bot.user.setActivity("Ай ДоНТ ХиАр Йу");
    }
    if(msg.content === "b!debug (set-stat-statosu)"){
        bot.user.setActivity(statosu);
    }
	if(msg.content === "b!debug (set-stat-statgta)"){
        bot.user.setActivity("GTA V Online");
    }
    if(msg.content === "b!debug (set-status-dnd)"){
        bot.user.setStatus('dnd')
    }
    if(msg.content === "b!debug (set-status-online)"){
        bot.user.setStatus('afp')
    }
    if(msg.content === "b!debug (set-status-inv)"){
        bot.user.setStatus('invisible')
    }
    if(msg.content === "b!debug (set-status-nothere)"){
        bot.user.setStatus('idle')
    }
    if(msg.content === "b!debug (set-stat-statminecraft)"){
        bot.user.setActivity(statminecraft);
    }
    if(msg.content === "b!debug (set-stat-statdota)"){
        bot.user.setActivity(statdota);
    }
	if(msg.content === "b!debug (set-stat-statfortnitebr)"){
        bot.user.setActivity("Fortnite: Battle Royale");
    }
	if(msg.content === "b!debug (set-stat-statfortnite)"){
        bot.user.setActivity("Fortnite");
    }
	if(msg.content === "b!debug (set-stat-statfortnitepve)"){
        bot.user.setActivity("Fortnite PVE");
    }
    if(msg.content === "b!debug (set-stat-statwot)"){
        bot.user.setActivity(statWoT);
    }
    if(msg.content === "b!debug (author)"){
        msg.channel.send("Создателем меня является Butterscotch#1583");
    }
    if(msg.content === "b!daily"){
        msg.channel.send("Дневная зарплата 50 рублей");
        bank += 50;
    }
    if(msg.content === "b!debug (shutka)"){
        msg.channel.setNSFW(true)
        msg.channel.send("LOL")
        msg.channel.setNSFW(false)
    }

    if(msg.content === "b!debug (reset)"){
        msg.channel.send("Сброшенно");
        bank = 0;
        inv = "";
        sms = 0;
        otm = 0;
        pere = 0;
        ludi = 0;
        console.log("Пользователь: " + msg.author.username + " сбросил данные переменных!")
    }
    if(msg.content === "b!debug (vita-bombit)"){
        msg.channel.send("http://dazsfr.ru/videoplayback.mp4");
    }
    if(msg.content === "b!debug (narkota)"){
        msg.channel.send("http://dazsfr.ru/videoplay.mp4");
    }
    if(msg.channel){
        console.log("Сообщение от автора " + msg.author.username + ". Вот его сообщение: " + msg.content);
        sms += 1;
        console.log("Теперь сообщений всего: " + sms);
    }
    if(msg.content === "b!debug (sms)"){
        msg.channel.send("Кол-во сообщений включая мои на всех серверах на которых я был за всё время составляет: " + sms + " сообщений.");
    }
    if(msg.content === "b!debug (mem)"){
        msg.channel.send("/tts валим валим вааалим на геликее....")
    }
    if(pere === 0){
        if(msg.content === "b!debug (sobr)"){
            msg.channel.send("@everyone Перекличка, отметьтесь командой: b!Я тут! ");
            pere = 1;
        }
    }else{
        if(msg.content === "b!debug (sobr)"){
            msg.channel.send("Сейчас и так перекличка!");
        }
    }
    if(msg.content === "b!debug (sobr-bototehnika)"){
        msg.channel.send("@everyone ВСЕ НА БОТОТЕХНИКУ ОНА НАЧАЛАСЬ!");
    }
    if(pere === 1){
        if(ludi === msg.author.username){
            if (msg.content === "b!Я тут!"){
                msg.channel.send("Ты уже есть в списке!");
            }
        }else{
            if (msg.content === "b!Я тут!"){
                let user = msg.author.username;
                msg.channel.send("Отлично! " + user + " тут!");
                ludi += " " + user + ",";
                otm += 1;
            }
        }
    }else{
        if (msg.content === "b!Я тут!"){
            msg.channel.send("Сейчас не перекличка!");
        }
    }
    if(pere === 1){
        if(msg.content === "b!debug (sobr-okoncheno)"){
            msg.channel.send("Перекличка окончена! Кто не успел, тот опоздал!");
            console.log("Людей было на перекличке: " + otm);
            otm = 0;
            pere = 0;
            ludi = "";
        }
    }else{
        if(msg.content === "b!debug (sobr-okoncheno)"){
            msg.channel.send("Сейчас нет переклички!");
        }
    }
    if(msg.content === "b!debug (otm)"){
        if(pere === 1){
            msg.channel.send("Отметилось человек: " + otm + " чел.");
            console.log("Вот эти люди:" + ludi);
        }else{
            msg.channel.send("Сейчас не перекличка.");
        }
    }
    if(msg.content === "!привет дружище"){
        msg.reply("Досвидание...");
    }
    if(msg.content === "b!debug (maybebaby)"){
        msg.reply("https://www.youtube.com/watch?v=Lfo29TGB8DQ");
    }
    if(msg.content === "b!debug (kartochka)"){
        let user = msg.author.username;
        if(user === "Андрей Юрьевич Урусов"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704783654525599784/unknown.png");
        }
        if(user === "Урусов Андрей Юрьевич"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704783654525599784/unknown.png");
        }
        if(user === "MihMin"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704788905429434448/unknown.png");
        }
        if(user === "Butterscotch"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704790431325749298/unknown.png");
        }
        if(user === "stari4ok"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704785459716423720/unknown.png");
        }
        if(user === "Дима Камешков"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704934653244604426/unknown.png");
        }
        if(user === "Rodion010"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/704937096175157318/unknown.png");
        }
        if(user === "Артем Пучков"){
            msg.reply("https://cdn.discordapp.com/attachments/530377397728706560/705098824896610394/unknown.png");
        }
    }
    if(msg.content === "b!invite"){
        msg.channel.send("```Вот ваше приглашение:```");
        msg.channel.send("https://discord.gg/t3xhwSW");
    }
    if(msg.content === "b!invite-bot"){
        msg.channel.send("```Вот ваше приглашение для бота:```");
        msg.channel.send("https://discordapp.com/api/oauth2/authorize?client_id=530371804464807938&permissions=8&scope=bot");
    }
    if(msg.content === "b!debug (authoring-tools)-index-code"){
        msg.channel.send("https://cdn.discordapp.com/attachments/530377397728706560/704941897319186482/index.js");
        msg.channel.send("```index-code```")
    }  
	if(msg.content === "b!Привет"){
		msg.channel.send("Привет, " + msg.author.username + " <:pivko:706783081478225931>");
    }
    if(msg.content === "b!chan-join"){
        async function join_vc(){
            await msg.member.voice.channel.join();
            }
            join_vc();
    }
    if(msg.content === "b!chan-leave"){
        async function leave_vc(){
            await msg.member.voice.channel.leave();
            }
            leave_vc();
    }
    if(msg.content === "b!raspis"){
        msg.member.voice.channel.setName("Урок_в_18-00")
    }
    if(msg.content === "b!chan-ofc"){
        async function limit_vc(){
            await msg.member.voice.channel.setUserLimit(2);
            }
            limit_vc();
    }
    if(msg.content === "b!chan-private"){
        async function limit_vc(){
            await msg.member.voice.channel.setUserLimit(1);
            }
            limit_vc();
    }
    if(msg.content === "b!debug (lol)"){
        msg.member.voice.kick()
    }
    if(msg.content === "b!sosiska"){
        msg.channel.send("<:sosiska:710935056989945857>")
    }
    if(msg.content === "<@!530371804464807938>"){
        msg.channel.send("Чё надо")
    }
    if(msg.content === "b!chan-public"){
        async function limit_vc(){
            await msg.member.voice.channel.setUserLimit(99);
            }
            limit_vc();
    }
    if(msg.content === "b!chan-create"){
        async function clone_vc(){
            await msg.member.voice.channel.clone();
            }
            clone_vc();
    }
    if(msg.content === "b!chan-name"){
        msg.member.voice.channel.setName(msg.author.username + "'s Channel")
    }
    if(msg.content === "b!chan-delete"){
        async function del_vc(){
            await msg.member.voice.channel.delete(msg.author.username + "'s Channel");
            }
            del_vc();
    }
});

bot.login(token);